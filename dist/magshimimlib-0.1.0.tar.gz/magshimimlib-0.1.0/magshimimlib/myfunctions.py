def what() -> str:
    return "Magshimim is a special program ment to bring high level of cyber eduction "
"to the periphery. It is a three-years program for students from 10th to 12th grade. "
"The program teaches a few programing languages, and also some wide understing of computers, "
"virtual networks, etc. The program helps the students get ready for a miningful service "
"in the inteligence community of Israel. It is considered a very valuable program for Israel's "
"cyber security."